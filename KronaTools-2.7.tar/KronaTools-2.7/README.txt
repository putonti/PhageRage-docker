For installation and usage instructions please refer to:
https://github.com/marbl/Krona/wiki/KronaTools

Tool names start with 'kt' (use TAB for completions) and can be run without
arguments to list options.

For feedback please see:
https://github.com/marbl/Krona/issues
