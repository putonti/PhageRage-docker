#!/bin/bash -e
# Run bowtie on pDNA reads against pDNA database
# Daniel Huson, 9.2012

if [ $# != 3 ] && [ $# != 8 ]
then
	echo "Usage: z4_bowtie-on-pdna.sh infile outfile pauda-index [L N K MP MS]"
	echo "	infile: pDNA reads in FastA format"
	echo "	outfile: pDNA matches in SAM format"
	echo "	pauda-index: location of pauda-index"
	echo "	L N K MP MS: bowtie parameters"
	exit 1
fi

bin_dir=`dirname "$0"`
bin_dir=`cd "$bin_dir" && pwd`

index_dir=$3

if [ ! -e $index_dir ]
then
	echo "PAUDA-index not found: $index_dir"
	exit 1
fi

program=bowtie2-align

if [ ! -z $BOWTIE_BIN ]
  then
        PATH="$BOWTIE_BIN":$PATH
fi
program_file=`which $program`

if [ -z $program_file ] || [ ! -e $program_file ]
 then
       echo $program": Command not found."
       echo "Please add bowtie2's bin directory to your PATH"
        echo "or set the environmental variable BOWTIE_BIN to it"
        exit 1
fi

input=$1
name=`echo $input|sed "s/.pna//"`
L=18
N=1
K=30

MP=3 # mismatch penalty
MS=35 # min-score

if [ $# == 8 ]
then
	L=$4
	N=$5
	K=$6
	MP=$7
	MS=$8
fi

threads=4
database=$index_dir/ref
output=$2

$program --mm --reorder  --sam-no-hd --mp $MP --score-min C,$MS -t -f -p $threads -k $K -N $N -L $L -i C,1 --local --no-unal --norc -x "$database" -U "$input" -S "$output"
