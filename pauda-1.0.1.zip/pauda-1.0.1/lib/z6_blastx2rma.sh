#!/bin/bash -e
# Make RMA file from reads file and blastx file
# Daniel Huson, 9.2012

if [ $# != 3 ]
then
	echo "Usage: z6_blastx2rma.sh DNA-file BLASTX-file RMA-file"
	echo "	DNA-file: original DNA reads in FastA format"
	echo "	BLASTX-file: file containing BLASTX matches"
	echo "	RMA-file: name of new RMA-file"
	exit 1
fi

bin_dir=`dirname "$0"`       # may be relative path
bin_dir=`cd "$bin_dir" && pwd`    # ensure absolute path
data=$bin_dir/../data
jar=$bin_dir/../lib/Pauda.jar

treefile=$data/ncbi.tre

fastafile=$1
blastxfile=$2
rmafile=$3

textStoragePolicy=inORIGINAL # alternatives: inRMA, inRMAZ, inORIGINAL

java -Xmx8G -server  -Duser.language=en -Duser.region=US -cp "$jar" megan.tools.Blast2RMAFile -i  $blastxfile -f "BlastX"  -r $fastafile -o "$rmafile" -tf "$treefile" -m 25 -tp $textStoragePolicy -class -dd "$data"
