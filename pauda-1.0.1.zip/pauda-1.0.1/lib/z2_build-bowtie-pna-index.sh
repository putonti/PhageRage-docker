#!/bin/bash  -e
# Build bowtie index on pDNA
# Daniel Huson, 9.2012

if  [ $# != 1 ]
then
	echo "Usage: z2_build-bowtie-pna-index pauda-index"
	echo "	pauda-index: location of pauda-index"
	exit 1
fi

bin_dir=`dirname "$0"`       
bin_dir=`cd "$bin_dir" && pwd`    

index_dir=$1

program=bowtie2-build
if [ ! -z $BOWTIE_BIN ]
  then
        PATH="$BOWTIE_BIN":$PATH
fi
program_file=`which $program`

if [ -z $program_file ] || [ ! -e $program_file ]
 then
       echo $program": Command not found."
       echo "Please add bowtie2's bin directory to your PATH"
	echo "or set the environmental variable BOWTIE_BIN to it"
        exit 1
fi

pnafile=$index_dir/ref.pna
index=$index_dir/ref
log=$index_dir/bowtie2-build.log

echo "Start: "`date`  |tee "$log"
echo "$program $pnafile $index" |tee -a "$log"
$program "$pnafile" "$index"  2>&1 |tee -a "$log"
echo "Finish: "`date`|tee -a "$log"
