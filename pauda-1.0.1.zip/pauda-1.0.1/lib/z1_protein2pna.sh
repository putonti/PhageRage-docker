#!/bin/bash -e
# Protein to pDNA script
# Daniel Huson, 9.2012

if [ $# != 2 ]
 then
	echo "Usage: z1_protein2pna.sh references-fasta pauda-index-directory"
	echo "	     references-fasta: protein sequences in fastA format"
	echo "	     pauda-index-directory: Directory for new PAUDA index"
	exit 1
fi

bin_dir=`dirname "$0"` 
bin_dir=`cd "$bin_dir" && pwd`

index_dir=$2

if [ ! -e $index_dir ]
then
	mkdir $index_dir
fi

reduction="BLOSUM50_4"

jar="$bin_dir/../lib/Pauda.jar"

cwd=`pwd`

# The next lines below are a replacement for a linux command that doesn't work under MACOS:  references=`readlink -f "$1"`
references=$1
cd `dirname $references`
references=`basename $references`
    echo "References: $references"

# Iterate down a (possible) chain of symlinks
while [ -L "$references" ]
do
    references=`readlink $references`
    cd `dirname $references`
    references=`basename $references`
    echo "References: $references"
done
dir=`pwd -P`
references=$dir/$references
# end of replacement

cd $cwd

name=$index_dir/ref.faa

echo "ln -s $references $name"
ln -s "$references" "$name"

log=$index_dir/protein2pna.log

echo "java -Xmx20G  -Duser.language=en -Duser.region=US -cp $jar megan.pauda.Proteins2PNA -a $reduction -i $name" 2>&1 |tee "$log"
java -Xmx20G  -Duser.language=en -Duser.region=US -cp "$jar" megan.pauda.Proteins2PNA -a $reduction -i "$name" 2>&1 |tee -a "$log"
