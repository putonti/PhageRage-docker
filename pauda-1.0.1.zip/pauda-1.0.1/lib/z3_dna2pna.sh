#!/bin/bash -e
# Convert DNA reads to pDNA
# Daniel Huson, 9.2012

if  [ $# != 2 ]
then
	echo "Usage: z3_dna2pna.sh infile outfile"
	echo "	infile: file containing DNA reads in FastA format"
	echo "	outfile: file containing translated proteins as pDNA in FastA format"
	exit 1
fi

bin_dir=`dirname "$0"`       # may be relative path
bin_dir=`cd "$bin_dir" && pwd`    # ensure absolute path
jar=$bin_dir/../lib/Pauda.jar

reduction="BLOSUM50_4"

java -Xmx2G  -Duser.language=en -Duser.region=US -cp "$jar" megan.pauda.DNA2PNA -a $reduction -i "$1" -o "$2"
