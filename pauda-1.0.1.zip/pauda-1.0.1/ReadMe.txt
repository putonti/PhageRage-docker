March 7th, 2013               README.txt

How to use PAUDA to perform an ultra-fast BLASTX-like DNA-to-protein database 
search using bowtie2. 

0. Requirements:

To run the scripts you need to install the following programms:
- Java runtime environment version 1.6 or higher
- Bowtie2, available from: http://bowtie-bio.sourceforge.net/bowtie2/index.shtml

We recommend that you use a 64-bit operating system with at least 16 GB of RAM,
but more memory is always better.
 
1. Installation:

1.1 Download and unzip the file pauda.zip to create a directory called pauda,
available from: http://www-ab.informatik.uni-tuebingen.de/software/pauda

1.2 PAUDA scripts will look for bowtie2 executables in your command path.
You can override this behavior by setting an environment variable BOWTIE_BIN to 
point to the directory that contains the bowtie2 programs.

1.3 The default directory for index files is called pauda-index and will be 
placed in the parent directory of pauda. Use the environment variable 
PAUDA_INDEX_DIR to specify an alternative pauda-index directory.
On a high memory machine, consider moving the index to /dev/shm to have it
in memory.

1.4 The environment variable PAUDA_TMP_DIR determines where temopary files
are placed. This should be a fast local disk such as /tmp. On a high memory
machine, consider setting this variable to /dev/shm to hold all temporary
files in memory.

2. Preparation of the PAUDA index:

Run the command pauda-build on the given protein reference database.

	pauda-build <input-database>

Example:
	pauda/bin/pauda-build refseq.r50.microbial.faa 

This is what the command pauda-build does:

First, a script z1_protein2pna.sh is run that translates the protein reference
database into pDNA and writes it to the pauda-index directory.
This requires 10-20 GB of main memory and takes a couple of hours
(as it also identifies and collapses all redundant pPNA sequences).

Second, a script z2_build-bowtie-pna-index.sh is used to run the program bowtie2-build on the pDNA database to
compute a bowtie index. This will take a couple of hours.

3. Running PAUDA on a file of reads

Run the command pauda-run on a file of reads to generate a 
BLASTX and, optionally, an RMA file (for use with the program MEGAN).

	pauda-run [--fast|--slow] <input-file> <blastx-file> [<rma-file>] [index-dir]
	
Example:
	pauda/bin/pauda-run hiseq_1.fna hiseq_1.blastx

The input file must be either in FASTA or FASTQ format.

This is what the command pauda-run does:

First, a script z3_dna2pna.sh is run that translates the DNA reads into
protein sequences and then recodes them as pDNA sequences.
This should only take a few minutes for a million reads.

Second, a script script z4_bowtie-on-pna.sh is launched. It runs
bowtie2-align to align the pDNA reads against the pDNA
reference database and the result is a SAM file containing all the found
pDNA alignments.
PAUDA will require about 15  minutes to process one million reads on four cores,
unless the command-line option --slow is specified, in which case the
run time will be much longer (but more reads will be assigned).

Parameters used when running bowtie2-align can be modified by editing
the file pauda/lib/z4_bowtie-on-pna.sh.

Third, a script z5_sam2blastx.sh is run to produce a file that contains all
statistically significant protein alignments found, in BLASTX format.
This program requires 20-30GB or main memory and requires
about 50 minutes to process the matches obtained for a million sequences.

Finally, if the name of an RMA file is given as input, this produces an RMA
file that can be opened by MEGAN. (This uses the script z6_blastx2rma.sh).
	
4. Supported environment variables:

The commands use the following environmental variables.

BOWTIE_BIN - location of directory that contains bowtie2-build and bowtie2-align
PAUDA_INDEX_DIR - location of index directory used by pauda

Setting the environment variables using tcsh:
setenv BOWTIE_BIN /raid/software/bowtie2-2.0.0-beta7
setenv PAUDA_INDEX_DIR /raid/data/pauda-index
setenv PAUDA_TMP_DIR /tmp

Setting the environment variables using bash:
export BOWTIE_BIN=/raid/software/bowtie2-2.0.0-beta7
export PAUDA_INDEX_DIR=/raid/data/pauda-index
export PAUDA_TMP_DIR=/tmp

5. Additional options:
Many of the commands have additional options that can be found by opening
the command in an editor. For example, by editing the file
pauda/bin/a5_sam2blastx.sh you can change the BLOSUM matrix, gap open
or gap score penalty used to evaluate the protein alignments.

Moreover, the underlying Java programs have additional command-line options.
These can be queried by running such a program with the command-line option
-h (for help).

6. Further details:
Please contact daniel.huson@uni-tuebingen.de for further details.
